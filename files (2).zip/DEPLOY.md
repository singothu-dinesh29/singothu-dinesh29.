# DD-Solutions EduAI — Deployment Guide

## 🚀 Fastest Way: Netlify (2 minutes, FREE)

### Step 1 — Sign up
Go to https://netlify.com → Sign up with Google or email (free)

### Step 2 — Deploy
1. Go to https://app.netlify.com/drop
2. Drag the `index.html` file into the drop zone
3. Wait ~10 seconds
4. Your site is LIVE! You'll get a URL like: `https://amazing-hopper-abc123.netlify.app`

### Step 3 — Custom Domain (optional)
- In Netlify dashboard → Domain Settings → Add custom domain
- Example: `eduai.ddcollege.edu` or `ddsolutions-eduai.netlify.app`

---

## ⚡ Alternative: GitHub Pages (free)

### Step 1
Create a GitHub account at https://github.com

### Step 2
- New repository → Name it `dd-eduai`
- Upload `index.html`
- Go to Settings → Pages → Source: main branch → Save

### Step 3
Your site is live at: `https://yourusername.github.io/dd-eduai`

---

## 🔥 Alternative: Vercel (instant, free)

1. Go to https://vercel.com → Sign up
2. Click "Add New Project" → Import your GitHub repo (or drag & drop)
3. Deploy → Live in 30 seconds
4. Custom domain available for free

---

## 💻 Run Locally (no internet needed)

Just double-click `index.html` — it opens in any browser!
Or run: `python3 -m http.server 8080` and open http://localhost:8080

---

## 📁 File Structure

```
dd-eduai/
├── index.html      ← Complete platform (single file, ~85KB)
└── DEPLOY.md       ← This file
```

Everything is in one self-contained HTML file. No build step, no npm, no dependencies.

---

## 🌐 Live Features in This Build

| Module              | Status |
|---------------------|--------|
| Dashboard           | ✅ Full |
| AI Chat Assistant   | ✅ Full (offline AI responses) |
| Study Schedule      | ✅ Full + Pomodoro timer |
| Learning Roadmaps   | ✅ Full (7 domains) |
| Attendance Tracker  | ✅ Full + Calendar |
| Faculty Directory   | ✅ Full (8 departments) |
| Campus Feed         | ✅ Full + Like/Save |
| Course Platform     | ✅ Full (6 courses) |
| Productivity Tracker| ✅ Full + Streaks + Badges |
| Admin Dashboard     | ✅ Full + Analytics |
| Dark/Light Mode     | ✅ Toggle |
| Multilingual        | ✅ EN/Telugu/Tamil/Hindi |
| Mobile Responsive   | ✅ Full |
| Voice Input (UI)    | ✅ Demo simulation |

---

## 🔗 To add real AI (OpenAI API)

Replace the `getAIReply()` function in the script with:

```javascript
async function getAIReply(q) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer YOUR_OPENAI_KEY'
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are an AI study assistant for DD-Solutions EduAI platform. Help students with academics, generate study schedules, and explain concepts. Support English, Telugu, Tamil, and Hindi.' },
        { role: 'user', content: q }
      ]
    })
  });
  const data = await res.json();
  return data.choices[0].message.content;
}
```

---

Built with ❤️ by DD-Solutions | AI Powered Smart Campus Platform
